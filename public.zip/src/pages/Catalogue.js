import React from 'react'
import Categories from '../components/Categories'
import Products from '../components/Products'

const Catalogue = () => {
  return (
    <div>
        <Categories/>
      <Products/>
    </div>
  )
}

export default Catalogue
