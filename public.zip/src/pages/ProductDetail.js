import './ProductDetail.css'

import ImageSlider from '../components/ImageSlider';
import { useParams } from "react-router-dom";
import { PRODUCTS } from '../PRODUCTS';
import React, { useState } from "react";
import Description from '../components/Description';
import Modal from '../components/Modal';
import OrderSubmitForm from '../components/OrderSubmitForm';

function ProductDetail() {  
  const { productName } = useParams();
  const foundProduct = PRODUCTS.find(product => product.name === productName);
  const [isModalVisible, setIsModalVisible] = useState(false);
  const handleShowModal = () => {
    setIsModalVisible(true);
  }
  const handleHideModal = () => {
    setIsModalVisible(false);
  }
    return (
      
      <div className="item-detail">
        <div className="item-block">
        <ImageSlider images ={foundProduct.imageUrls} ></ImageSlider>
        
       <Description product ={foundProduct} handleShowModal={handleShowModal}></Description>
       {isModalVisible &&(
        <Modal onHideModal = {handleHideModal}>
          <div>
            <OrderSubmitForm></OrderSubmitForm>
          </div>
        </Modal>
       )}
       </div>
      </div>
    );
  }
  
  export default ProductDetail;