import React, { useState } from 'react';
import './Product.css'
import { Link } from 'react-router-dom';
const Product = ({ imgSrc, itemName, condition, price, location,  }) => {
  return (
    <div className="item">
    <Link to={{ pathname: `/product/${itemName}` }}> 
    <img className="item-img" src={imgSrc} alt={itemName} />
    </Link>
      <div className="item-section-one">
        <div className="item-section-two">
          <div>
            <h2 className="item-name">{itemName}</h2>
            <p className="state">{condition}</p>
          </div>
          <p className="price">{price} $</p>
        </div>
        <div className="location-descr">
          <img src="./img/location.png" alt="Location" />
          <p>{location}</p>
        </div>
      </div>
    </div>
  );
};

export default Product;
