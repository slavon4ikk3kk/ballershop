import React, { useState } from 'react';
import './ImageSlider.css'

function ImageSlider(props) {
  const imageUrls = props.images;
  const [currentImage, setCurrentImage] = useState(0);
  const nextImage = () => {
    setCurrentImage((prevImage) =>
      prevImage < imageUrls.length - 1 ? prevImage + 1 : 0
    );
  };

  const prevImage = () => {
    setCurrentImage((prevImage) =>
      prevImage > 0 ? prevImage - 1 : imageUrls.length - 1
    );
  };

  const isAtFirstImage = currentImage === 0;
  const isAtLastImage = currentImage === imageUrls.length - 1;
  return (
    <div>
      <div className="image-container-slider">
      <div className={`left-arrow ${isAtFirstImage ? 'hidden' : ''}`} onClick={prevImage}><img src='/img/arrow.png'/></div>
        <div className="image-slider">
          <img src={imageUrls[currentImage]} alt={`Image ${currentImage}`} />
        </div>
        <div className={`right-arrow ${isAtLastImage ? 'hidden' : ''}`} onClick={nextImage}><img src='/img/arrow.png'/></div>
      </div>
    </div>
  );
}

export default ImageSlider;

