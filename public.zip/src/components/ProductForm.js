import React, { useState, useCallback, useContext } from 'react';
import { useAuth } from '../AuthContext';
import './ProductForm.css';
function ProductForm() {
 
    const [formData, setFormData] = useState({
      name: '',
      state: '',
      price: '',
      productImage: "./placeholder.png",
      imageUrls: [],
      location: '',
      cushioning: '',
      traction: '',
      supportive: '',
      lightweight: '',
      durability: '',
      signature: '',
      versality: '',
      description:''
    });
    const {user, logout} = useAuth();
    const {isSubmitted, setIsSubmitted} = useState(false); 
    const handleSubmit = async (e) => {
      e.preventDefault();
      if(!user){
        alert("You must be logged in to submit a product.");
        return;
      }
      /*if(!formData.productImage && formData.imageUrls.length === 0) {
        alert("Please add at least one image for the product.");
        return;
      } */
      try{
        const formDataWithUser = {
          ...formData,
          user: user,
        };

        const response = await fetch("http://localhost:5001/product", {
          method: "POST",
          headers: {
            'Content-Type': "application/json",
          },
          body: JSON.stringify(formDataWithUser),
        });
        if(!response.ok) {
          throw new Error('failed to add product')
        }
        console.log('Product added successfully')
        setIsSubmitted(true);
      } catch (error){
        console.error('There was a problem adding the product', error);
      }
    };
    const handleChange = (e) => {
      const { name, value } = e.target;
      setFormData(prevFormData => ({
        ...prevFormData,
        [name]: value 
      }));
    };
  return (
    <form className="submitForm" onSubmit={handleSubmit} > 

    <h2>Add Product</h2> 
    <input name="name" type="text" placeholder="Name" onChange={handleChange} value={formData.name} required /> {/*назва*/}
  
    <select name="state" onChange={handleChange} value={formData.state} required>{/*стан*/}
      <option value="">Select State</option> 
      <option value="new">New</option>
      <option value="used">Used</option>
    </select>
    <input name="price" type="number" placeholder="Price"  onChange={handleChange} value={formData.price} required />{/*ціна*/}
 
    <input name="location" type="text" placeholder="Location" onChange={handleChange} value={formData.location} required />{/*місце*/}

    <input name="cushioning" type="text" placeholder="Cushioning" onChange={handleChange} value={formData.cushioning}/>
    <input name="traction" type="text" placeholder="Traction"  onChange={handleChange} value={formData.traction}/>
    <input name="supportive" type="text" placeholder="Supportive" onChange={handleChange} value={formData.supportive}/>
    <input name="lightweight" type="text" placeholder="Lightweight"  onChange={handleChange} value={formData.lightweight} />
    <input name="durability" type="text" placeholder="Durability" onChange={handleChange} value={formData.durability}/>
    <input name="signature" type="text" placeholder="Signature" onChange={handleChange} value={formData.signature}/>
    <input name="versatility" type="text" placeholder="Versatility" onChange={handleChange} value={formData.versality}/>
    <textarea name="description" placeholder="Description" onChange={handleChange} value={formData.description} required /> {/*опис*/}
    
  {/*місце для перетягування зображень*/}
    <div
      className="dropArea" 
    >
      Drag and drop additional images here
    </div>
    <button type="submit">Submit</button>
  </form>
  );
}

export default ProductForm;
